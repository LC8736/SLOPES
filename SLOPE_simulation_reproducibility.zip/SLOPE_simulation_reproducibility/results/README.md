# Result directories

- `reported/` contains the replication-level and summarized results used in the
  current manuscript. These files are versioned and should not be overwritten.
- `recomputed/` is created by `Rscript run_all.R full`.
- `smoke/` is created by `Rscript run_all.R smoke`.

The latter two directories are excluded by `.gitignore`. See
`../RESULTS_CODEBOOK.md` for variable definitions and
`../MANUSCRIPT_RESULTS.md` for the manuscript mapping.

