options(stringsAsFactors = FALSE)

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (!length(script_arg)) stop("Run this file with Rscript.")
this_file <- normalizePath(sub("^--file=", "", script_arg[1L]), winslash = "/", mustWork = TRUE)
code_dir <- dirname(this_file)
results_name <- Sys.getenv("DIVVY_RESULTS_DIR", unset = "reproduced_results")

run_script <- function(name) {
  status <- system2(
    command = file.path(R.home("bin"), "Rscript"),
    args = file.path(code_dir, name),
    env = paste0("DIVVY_RESULTS_DIR=", results_name)
  )
  if (!identical(status, 0L)) stop(name, " failed with status ", status)
}

run_script("run_divvy2019_q1_updated_model.R")
run_script("plot_tuning_sensitivity.R")
run_script("plot_anomaly_map.R")
run_script("plot_test_statistic_density.R")
run_script("summarize_spatial_patterns.R")
message("All updated Divvy analyses completed in ", results_name, ".")
