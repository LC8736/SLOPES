options(stringsAsFactors = FALSE)
suppressPackageStartupMessages(library(data.table))

# Self-contained implementation of the updated Chicago Divvy application.
# All paths are resolved relative to this script.

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (!length(script_arg)) stop("Run this file with Rscript.")
this_file <- normalizePath(sub("^--file=", "", script_arg[1L]), winslash = "/", mustWork = TRUE)
bundle_dir <- normalizePath(file.path(dirname(this_file), ".."), winslash = "/")

panel_file <- file.path(bundle_dir, "data", "divvy2019_q1_updated_model_data.csv")
coord_file <- file.path(bundle_dir, "data", "divvy2019_station_temperature_grid_mapping.csv")
results_name <- Sys.getenv("DIVVY_RESULTS_DIR", unset = "reproduced_results")
out_dir <- file.path(bundle_dir, results_name)
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

model_start_date <- as.IDate("2019-01-01")
model_end_date <- as.IDate("2019-03-31")
alpha <- 0.05
default_cC <- 1.0
default_kc <- 0.6

d <- fread(panel_file)
required_columns <- c("station_id", "station_name", "date", "departures",
                      "temp_it_c", "prcp_it_mm", "swe_kg_m2")
if (!all(required_columns %in% names(d))) {
  stop("Missing columns: ", paste(setdiff(required_columns, names(d)), collapse = ", "))
}
d[, `:=`(
  station_id = as.character(station_id),
  date = as.IDate(date),
  y_raw = log1p(departures),
  temp_raw = temp_it_c,
  prcp_raw = prcp_it_mm,
  swe_raw = swe_kg_m2
)]
d <- d[date >= model_start_date & date <= model_end_date]
setorder(d, station_id, date)

ids <- sort(unique(d$station_id))
dates <- sort(unique(d$date))
n <- length(ids)
TT <- length(dates)
stopifnot(n == 344L, TT == 90L, nrow(d) == n * TT)
stopifnot(!anyDuplicated(d[, .(station_id, date)]))
stopifnot(all(d[, .N, by = station_id]$N == TT))
numeric_columns <- c("departures", "temp_it_c", "prcp_it_mm", "swe_kg_m2")
stopifnot(all(vapply(d[, ..numeric_columns],
                         function(z) all(is.finite(z)), logical(1))))

wide <- function(value) {
  w <- dcast(d, date ~ station_id, value.var = value)
  setorder(w, date)
  ans <- as.matrix(w[, ..ids])
  colnames(ans) <- ids
  ans
}
standardize <- function(M) (M - mean(M)) / sd(as.vector(M))
within_station <- function(M) sweep(M, 2L, colMeans(M), "-")
common_matrix <- function(v) within_station(matrix(rep(v, n), nrow = TT, ncol = n))

Yraw <- wide("y_raw")
Xraw <- list(
  Temperature = wide("temp_raw"),
  PRCP = wide("prcp_raw"),
  SWE = wide("swe_raw")
)
Yw <- within_station(standardize(Yraw))
main_mats <- lapply(Xraw, function(M) within_station(standardize(M)))

weekend <- as.numeric(as.POSIXlt(as.Date(dates))$wday %in% c(0L, 6L))
holiday_dates <- as.IDate(c("2019-01-01", "2019-01-21", "2019-02-18"))
holiday <- as.numeric(dates %in% holiday_dates)
control_mats <- list(
  Weekend = common_matrix(weekend),
  Holiday = common_matrix(holiday)
)

p_main <- length(main_mats)
Xi <- vector("list", n)
Qi <- vector("list", n)
xtx_inv <- vector("list", n)
for (i in seq_len(n)) {
  Xi[[i]] <- do.call(cbind, lapply(main_mats, function(M) M[, i]))
  Qi[[i]] <- do.call(cbind, lapply(control_mats, function(M) M[, i]))
  colnames(Xi[[i]]) <- names(main_mats)
  colnames(Qi[[i]]) <- names(control_mats)
  xtx_inv[[i]] <- solve(crossprod(Xi[[i]]))
}

# The theoretical radius is C0 = c_C T^(-1/3).
C0_base <- TT^(-1 / 3)

fit_updated_model <- function(Yin, cC = default_cC, kc = default_kc) {
  # Partial out each station's three weather slopes to estimate the two
  # common calendar coefficients.
  A <- matrix(0, length(control_mats), length(control_mats))
  b <- numeric(length(control_mats))
  for (i in seq_len(n)) {
    X <- Xi[[i]]; Q <- Qi[[i]]; inv <- xtx_inv[[i]]
    MxQ <- Q - X %*% inv %*% crossprod(X, Q)
    Mxy <- Yin[, i] - X %*% inv %*% crossprod(X, Yin[, i])
    A <- A + crossprod(Q, MxQ)
    b <- b + as.numeric(crossprod(Q, Mxy))
  }
  theta <- as.numeric(solve(A, b))
  names(theta) <- names(control_mats)

  beta_initial <- matrix(NA_real_, n, p_main,
                         dimnames = list(ids, names(main_mats)))
  unrestricted_residuals <- matrix(NA_real_, TT, n,
                                   dimnames = list(as.character(dates), ids))
  for (i in seq_len(n)) {
    adjusted_y <- Yin[, i] - Qi[[i]] %*% theta
    beta_initial[i, ] <- xtx_inv[[i]] %*% crossprod(Xi[[i]], adjusted_y)
    unrestricted_residuals[, i] <- adjusted_y - Xi[[i]] %*% beta_initial[i, ]
  }

  beta_norm2 <- rowSums(beta_initial^2)
  distances <- sqrt(pmax(outer(beta_norm2, beta_norm2, "+") -
                           2 * tcrossprod(beta_initial), 0))
  radius <- cC * C0_base
  neighbor_score <- (rowSums(distances <= radius) - 1L) / (n - 1L)
  reference_n <- floor(kc * n)
  reference_idx <- order(-neighbor_score, ids)[seq_len(reference_n)]
  reference <- seq_len(n) %in% reference_idx

  xx <- matrix(0, p_main, p_main)
  xy <- numeric(p_main)
  for (i in which(reference)) {
    adjusted_y <- Yin[, i] - Qi[[i]] %*% theta
    xx <- xx + crossprod(Xi[[i]])
    xy <- xy + as.numeric(crossprod(Xi[[i]], adjusted_y))
  }
  beta_common <- as.numeric(solve(xx, xy))
  names(beta_common) <- names(main_mats)

  restricted_residuals <- matrix(NA_real_, TT, n,
                                 dimnames = list(as.character(dates), ids))
  lm_component <- numeric(n)
  for (i in seq_len(n)) {
    restricted_residuals[, i] <- Yin[, i] - Qi[[i]] %*% theta -
      Xi[[i]] %*% beta_common
    score <- as.numeric(crossprod(Xi[[i]], restricted_residuals[, i]))
    lm_component[i] <- as.numeric(crossprod(score, xtx_inv[[i]] %*% score))
  }
  sigma2 <- sum(restricted_residuals[, reference, drop = FALSE]^2) /
    (reference_n * (TT - 1L))
  statistic <- lm_component / sigma2
  p_value <- pchisq(statistic, df = p_main, lower.tail = FALSE)

  order_p <- order(p_value, ids)
  eligible <- which(n * p_value[order_p] / seq_len(n) <= alpha)
  j_star <- if (length(eligible)) max(eligible) else 0L
  fdr_threshold <- if (j_star > 0L) alpha * j_star / n else 0
  rejected <- p_value <= fdr_threshold & fdr_threshold > 0

  list(
    theta = theta,
    beta_initial = beta_initial,
    beta_common = beta_common,
    unrestricted_residuals = unrestricted_residuals,
    restricted_residuals = restricted_residuals,
    distance_radius = radius,
    neighbor_score = neighbor_score,
    reference = reference,
    reference_n = reference_n,
    sigma2 = sigma2,
    statistic = statistic,
    p_value = p_value,
    p_bh = p.adjust(p_value, method = "BH"),
    fdr_threshold = fdr_threshold,
    rejected = rejected
  )
}

fit <- fit_updated_model(Yw)
stopifnot(sum(fit$rejected) == 22L)
stopifnot(sum(fit$rejected & fit$beta_initial[, "Temperature"] > fit$beta_common["Temperature"]) == 14L)
stopifnot(sum(fit$rejected & fit$beta_initial[, "Temperature"] < fit$beta_common["Temperature"]) == 8L)

scale_stats <- data.table(
  variable = c("log1p_departures", "daymet_mean_temperature_c",
               "daymet_prcp_mm", "daymet_swe_kg_m2"),
  mean = c(mean(Yraw), vapply(Xraw, mean, numeric(1))),
  sd = c(sd(as.vector(Yraw)), vapply(Xraw, function(M) sd(as.vector(M)), numeric(1)))
)
y_sd <- scale_stats[variable == "log1p_departures", sd]
x_sd <- setNames(scale_stats[variable != "log1p_departures", sd], names(main_mats))
raw_conversion <- y_sd / x_sd
beta_common_raw <- fit$beta_common * raw_conversion

coords <- fread(coord_file)
coords[, station_id := as.character(station_id)]
station_meta <- d[, .(
  station_name = station_name[1L],
  q1_total_departures = sum(departures),
  mean_daily_departures = mean(departures),
  zero_departure_days = sum(departures == 0)
), by = station_id]

station_results <- data.table(
  station_id = ids,
  rejected_joint_test = fit$rejected,
  temperature_direction = fifelse(
    !fit$rejected, "Not rejected",
    fifelse(fit$beta_initial[, "Temperature"] > fit$beta_common["Temperature"],
            "Above", "Below")
  ),
  preliminary_reference = fit$reference,
  neighborhood_score = fit$neighbor_score,
  test_statistic_chisq3 = fit$statistic,
  p_value = fit$p_value,
  p_bh = fit$p_bh,
  fdr_threshold = fit$fdr_threshold,
  beta_temperature_station_std = fit$beta_initial[, "Temperature"],
  beta_temperature_common_std = fit$beta_common["Temperature"],
  temperature_deviation_std = fit$beta_initial[, "Temperature"] - fit$beta_common["Temperature"],
  beta_prcp_station_std = fit$beta_initial[, "PRCP"],
  beta_prcp_common_std = fit$beta_common["PRCP"],
  prcp_deviation_std = fit$beta_initial[, "PRCP"] - fit$beta_common["PRCP"],
  beta_swe_station_std = fit$beta_initial[, "SWE"],
  beta_swe_common_std = fit$beta_common["SWE"],
  swe_deviation_std = fit$beta_initial[, "SWE"] - fit$beta_common["SWE"],
  euclidean_deviation_std = sqrt(rowSums(sweep(fit$beta_initial, 2L, fit$beta_common, "-")^2)),
  beta_temperature_station_log_per_c = fit$beta_initial[, "Temperature"] * raw_conversion["Temperature"],
  beta_prcp_station_log_per_mm = fit$beta_initial[, "PRCP"] * raw_conversion["PRCP"],
  beta_swe_station_log_per_kg_m2 = fit$beta_initial[, "SWE"] * raw_conversion["SWE"],
  temperature_effect_pct_per_c = 100 * (exp(fit$beta_initial[, "Temperature"] * raw_conversion["Temperature"]) - 1),
  prcp_effect_pct_per_mm = 100 * (exp(fit$beta_initial[, "PRCP"] * raw_conversion["PRCP"]) - 1),
  swe_effect_pct_per_kg_m2 = 100 * (exp(fit$beta_initial[, "SWE"] * raw_conversion["SWE"]) - 1)
)
station_results <- merge(station_results, station_meta, by = "station_id", all.x = TRUE)
station_results <- merge(
  station_results,
  coords[, .(station_id, station_lat, station_lon,
             daymet_grid_x_m, daymet_grid_y_m, distance_to_grid_center_km)],
  by = "station_id", all.x = TRUE
)
setorder(station_results, p_value, station_id)

model_summary <- data.table(
  model = "station-specific Temp, PRCP, and SWE slopes; common Weekend and Holiday effects",
  sample_start = as.character(model_start_date),
  sample_end = as.character(model_end_date),
  N = n, T = TT, NT = n * TT,
  C0_rule = "c_C * T^(-1/3)",
  c_C = default_cC,
  C0 = fit$distance_radius,
  k_c = default_kc,
  preliminary_reference_n = fit$reference_n,
  nominal_FDR = alpha,
  fdr_threshold = fit$fdr_threshold,
  joint_discoveries = sum(fit$rejected),
  above_common_temperature_component = sum(fit$rejected & station_results[match(ids, station_id), temperature_direction] == "Above"),
  below_common_temperature_component = sum(fit$rejected & station_results[match(ids, station_id), temperature_direction] == "Below"),
  beta_temperature_common_std = fit$beta_common["Temperature"],
  beta_prcp_common_std = fit$beta_common["PRCP"],
  beta_swe_common_std = fit$beta_common["SWE"],
  beta_temperature_common_log_per_c = beta_common_raw["Temperature"],
  beta_prcp_common_log_per_mm = beta_common_raw["PRCP"],
  beta_swe_common_log_per_kg_m2 = beta_common_raw["SWE"],
  temperature_effect_pct_per_c = 100 * (exp(beta_common_raw["Temperature"]) - 1),
  prcp_effect_pct_per_mm = 100 * (exp(beta_common_raw["PRCP"]) - 1),
  swe_effect_pct_per_kg_m2 = 100 * (exp(beta_common_raw["SWE"]) - 1),
  weekend_coefficient_std_y = fit$theta["Weekend"],
  holiday_coefficient_std_y = fit$theta["Holiday"],
  sigma2_reference = fit$sigma2
)

# A1 diagnostic: contemporaneous correlations of unrestricted residuals.
rho <- cor(fit$unrestricted_residuals)
upper <- upper.tri(rho)
rho_values <- rho[upper]
corr_summary <- function(v) data.table(
  pair_count = length(v),
  signed_mean = mean(v),
  signed_median = median(v),
  mean_absolute = mean(abs(v)),
  abs_p25 = quantile(abs(v), .25),
  abs_p50 = quantile(abs(v), .50),
  abs_p75 = quantile(abs(v), .75),
  abs_p90 = quantile(abs(v), .90),
  abs_p95 = quantile(abs(v), .95),
  abs_r_lt_0_3 = mean(abs(v) < .3),
  abs_r_gt_0_3 = mean(abs(v) > .3),
  abs_r_gt_0_5 = mean(abs(v) > .5),
  abs_r_gt_0_8 = mean(abs(v) > .8)
)
residual_correlation_summary <- cbind(
  data.table(group = "All station pairs"),
  corr_summary(rho_values)
)

# A3 diagnostics requested for this bundle: residual ACF and ARCH-LM(q=7).
arch_lm <- function(e, q = 7L) {
  squared <- e^2
  response <- squared[(q + 1L):length(squared)]
  lags <- sapply(seq_len(q), function(h) squared[(q + 1L - h):(length(squared) - h)])
  auxiliary <- lm(response ~ lags)
  statistic <- length(response) * summary(auxiliary)$r.squared
  c(statistic = statistic, p_value = pchisq(statistic, df = q, lower.tail = FALSE))
}
acf_rows <- vector("list", n)
arch_rows <- vector("list", n)
for (i in seq_len(n)) {
  e <- fit$unrestricted_residuals[, i]
  acf_values <- as.numeric(acf(e, plot = FALSE, lag.max = 14L)$acf[-1L])
  acf_rows[[i]] <- data.table(
    station_id = ids[i], lag = seq_len(14L), acf = acf_values,
    preliminary_reference = fit$reference[i]
  )
  arch <- arch_lm(e, q = 7L)
  arch_rows[[i]] <- data.table(
    station_id = ids[i], statistic = arch["statistic"], p_raw = arch["p_value"],
    preliminary_reference = fit$reference[i]
  )
}
station_acf <- rbindlist(acf_rows)
station_arch <- rbindlist(arch_rows)
station_arch[, p_bh := p.adjust(p_raw, method = "BH")]
station_arch[, `:=`(reject_raw_5pct = p_raw < .05, reject_bh_5pct = p_bh < .05)]

acf_samples <- rbind(
  copy(station_acf)[, sample := "All stations"],
  copy(station_acf[preliminary_reference == TRUE])[, sample := "Preliminary reference set"]
)
acf_summary <- acf_samples[, .(
  station_count = .N,
  mean_acf = mean(acf), median_acf = median(acf),
  q25_acf = quantile(acf, .25), q75_acf = quantile(acf, .75),
  mean_absolute_acf = mean(abs(acf)),
  abs_acf_p90 = quantile(abs(acf), .90),
  abs_acf_p95 = quantile(abs(acf), .95)
), by = .(sample, lag)]
arch_samples <- rbind(
  copy(station_arch)[, sample := "All stations"],
  copy(station_arch[preliminary_reference == TRUE])[, sample := "Preliminary reference set"]
)
arch_summary <- arch_samples[, .(
  station_count = .N,
  median_statistic = median(statistic), median_p_raw = median(p_raw),
  raw_reject_count = sum(reject_raw_5pct),
  raw_reject_proportion = mean(reject_raw_5pct),
  bh_reject_count = sum(reject_bh_5pct),
  bh_reject_proportion = mean(reject_bh_5pct)
), by = sample]

# Application-level tuning sensitivity requested by the referee.
tuning_grid <- CJ(k_c = c(.5, .6, .7, .8), c_C = c(1.0, 1.1, 1.2, 1.3))
setorder(tuning_grid, k_c, c_C)
tuning_rows <- vector("list", nrow(tuning_grid))
tuning_station_rows <- vector("list", nrow(tuning_grid))
for (g in seq_len(nrow(tuning_grid))) {
  fg <- fit_updated_model(Yw, cC = tuning_grid$c_C[g], kc = tuning_grid$k_c[g])
  direction <- fifelse(
    !fg$rejected, "Not detected",
    fifelse(fg$beta_initial[, "Temperature"] > fg$beta_common["Temperature"], "Above", "Below")
  )
  tuning_rows[[g]] <- data.table(
    k_c = tuning_grid$k_c[g], c_C = tuning_grid$c_C[g],
    C0 = fg$distance_radius,
    theory_region_c_C_gt_k_c = tuning_grid$c_C[g] > tuning_grid$k_c[g],
    preliminary_reference_n = fg$reference_n,
    discoveries = sum(fg$rejected),
    above = sum(direction == "Above"), below = sum(direction == "Below"),
    beta_temperature_common_std = fg$beta_common["Temperature"],
    beta_prcp_common_std = fg$beta_common["PRCP"],
    beta_swe_common_std = fg$beta_common["SWE"],
    overlap_with_default = sum(fg$rejected & fit$rejected),
    union_with_default = sum(fg$rejected | fit$rejected),
    jaccard_with_default = sum(fg$rejected & fit$rejected) / sum(fg$rejected | fit$rejected)
  )
  tuning_station_rows[[g]] <- data.table(
    k_c = tuning_grid$k_c[g], c_C = tuning_grid$c_C[g],
    station_id = ids,
    rejected = fg$rejected,
    temperature_direction = direction,
    p_value = fg$p_value,
    p_bh = p.adjust(fg$p_value, method = "BH")
  )
}
tuning_summary <- rbindlist(tuning_rows)
tuning_station_results <- rbindlist(tuning_station_rows)

fwrite(model_summary, file.path(out_dir, "model_summary.csv"))
fwrite(scale_stats, file.path(out_dir, "standardization_parameters.csv"))
fwrite(station_results, file.path(out_dir, "station_results.csv"))
anomaly_export <- station_results[
  rejected_joint_test == TRUE,
  !c("q1_total_departures", "mean_daily_departures", "zero_departure_days"),
  with = FALSE
]
fwrite(anomaly_export, file.path(out_dir, "detected_anomalies.csv"))
fwrite(residual_correlation_summary, file.path(out_dir, "residual_correlation_summary.csv"))
fwrite(station_acf, file.path(out_dir, "station_acf.csv"))
fwrite(acf_summary, file.path(out_dir, "acf_summary.csv"))
fwrite(station_arch, file.path(out_dir, "station_arch_lm.csv"))
fwrite(arch_summary, file.path(out_dir, "arch_lm_summary.csv"))
fwrite(tuning_summary, file.path(out_dir, "tuning_sensitivity_summary.csv"))
fwrite(tuning_station_results, file.path(out_dir, "tuning_station_results.csv"))

capture.output(sessionInfo(), file = file.path(out_dir, "sessionInfo.txt"))

cat("Updated Divvy application completed.\n")
print(model_summary)
cat("\nResidual-correlation summary:\n")
print(residual_correlation_summary)
cat("\nACF lag 1 and lag 7:\n")
print(acf_summary[sample == "All stations" & lag %in% c(1L, 7L)])
cat("\nARCH-LM summary:\n")
print(arch_summary)
cat("\nTuning sensitivity:\n")
print(tuning_summary[, .(k_c, c_C, discoveries, overlap_with_default, jaccard_with_default)])
