options(stringsAsFactors = FALSE)
suppressPackageStartupMessages({
  library(data.table)
  library(ggplot2)
})

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (!length(script_arg)) stop("Run this file with Rscript.")
this_file <- normalizePath(sub("^--file=", "", script_arg[1L]),
                           winslash = "/", mustWork = TRUE)
bundle_dir <- normalizePath(file.path(dirname(this_file), ".."), winslash = "/")
results_name <- Sys.getenv("DIVVY_RESULTS_DIR", unset = "reproduced_results")
results_dir <- file.path(bundle_dir, results_name)

input_file <- file.path(results_dir, "station_results.csv")
if (!file.exists(input_file)) {
  stop("Missing station_results.csv. Run run_divvy2019_q1_updated_model.R first.")
}

d <- fread(input_file)
required <- c("station_id", "rejected_joint_test", "temperature_direction",
              "test_statistic_chisq3", "fdr_threshold")
if (!all(required %in% names(d))) {
  stop("Missing columns: ", paste(setdiff(required, names(d)), collapse = ", "))
}

d[, station_id := as.character(station_id)]
d[, plot_group := fifelse(
  rejected_joint_test & temperature_direction == "Above", "Above anomaly",
  fifelse(rejected_joint_test & temperature_direction == "Below",
          "Below anomaly", "Not detected")
)]

anomalies <- d[rejected_joint_test == TRUE]
stopifnot(nrow(d) == 344L, nrow(anomalies) == 22L)

# Because all station tests have three degrees of freedom, the BH p-value
# threshold has a one-to-one equivalent on the chi-square statistic scale.
bh_p_cutoff <- unique(d$fdr_threshold)
stopifnot(length(bh_p_cutoff) == 1L)
bh_stat_cutoff <- qchisq(1 - bh_p_cutoff, df = 3L)

density_fit <- density(
  d$test_statistic_chisq3,
  from = 0,
  to = max(d$test_statistic_chisq3) * 1.04,
  n = 2048L,
  adjust = 0.90
)
density_data <- data.table(test_statistic = density_fit$x,
                           density = density_fit$y)
group_colors <- c("Above anomaly" = "#D9483B", "Below anomaly" = "#2878B5")

p <- ggplot() +
  geom_area(
    data = density_data,
    aes(x = test_statistic, y = density),
    fill = "#8CB9D9", alpha = 0.38
  ) +
  geom_line(
    data = density_data,
    aes(x = test_statistic, y = density),
    color = "#28658C", linewidth = 1.15
  ) +
  geom_vline(
    xintercept = bh_stat_cutoff,
    color = "#333333", linewidth = 0.75, linetype = "22"
  ) +
  annotate(
    "text", x = bh_stat_cutoff, y = max(density_fit$y) * 0.95,
    label = sprintf("BH cutoff = %.2f", bh_stat_cutoff),
    hjust = -0.08, vjust = 0, size = 3.8, color = "#333333"
  ) +
  geom_rug(
    data = anomalies[plot_group == "Above anomaly"],
    aes(x = test_statistic_chisq3, color = plot_group),
    sides = "b", linewidth = 1.45, length = grid::unit(0.075, "npc")
  ) +
  geom_rug(
    data = anomalies[plot_group == "Below anomaly"],
    aes(x = test_statistic_chisq3, color = plot_group),
    sides = "b", linewidth = 1.45, length = grid::unit(0.038, "npc")
  ) +
  scale_color_manual(
    values = group_colors,
    breaks = c("Above anomaly", "Below anomaly"),
    name = NULL
  ) +
  scale_x_continuous(
    name = expression("Station-level joint test statistic " ~ W[i]),
    expand = expansion(mult = c(0.01, 0.045))
  ) +
  scale_y_continuous(
    name = "Density",
    expand = expansion(mult = c(0, 0.08))
  ) +
  coord_cartesian(clip = "off") +
  theme_classic(base_size = 14, base_family = "Arial") +
  theme(
    axis.title = element_text(size = 14),
    axis.text = element_text(size = 12, color = "#333333"),
    legend.position = "top",
    legend.justification = "left",
    legend.text = element_text(size = 13),
    legend.key.width = grid::unit(1.25, "lines"),
    plot.margin = margin(12, 28, 12, 12)
  )

output_file <- file.path(results_dir, "test_statistic_density.png")
ggsave(
  output_file, p,
  width = 11.5, height = 7.5, units = "in", dpi = 330,
  bg = "white"
)
message("Saved: ", output_file)
