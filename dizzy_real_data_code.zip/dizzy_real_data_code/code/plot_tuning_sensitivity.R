options(stringsAsFactors = FALSE)
suppressPackageStartupMessages(library(data.table))

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (!length(script_arg)) stop("Run this file with Rscript.")
this_file <- normalizePath(sub("^--file=", "", script_arg[1L]), winslash = "/", mustWork = TRUE)
bundle_dir <- normalizePath(file.path(dirname(this_file), ".."), winslash = "/")
results_name <- Sys.getenv("DIVVY_RESULTS_DIR", unset = "results")
results_dir <- file.path(bundle_dir, results_name)

input_file <- file.path(results_dir, "tuning_station_results.csv")
if (!file.exists(input_file)) stop("Run run_divvy2019_q1_updated_model.R first.")
d <- fread(input_file)
d[, station_id := as.character(station_id)]

default <- d[k_c == .6 & c_C == 1.0]
union_ids <- unique(d[rejected == TRUE, station_id])
above_ids <- default[temperature_direction == "Above", station_id]
below_ids <- default[temperature_direction == "Below", station_id]
extra_ids <- setdiff(union_ids, c(above_ids, below_ids))
station_order <- as.character(c(sort(as.integer(above_ids)),
                                sort(as.integer(extra_ids)),
                                sort(as.integer(below_ids))))

row_grid <- unique(d[, .(k_c, c_C)])
setorder(row_grid, k_c, c_C)
display <- matrix(0L, nrow(row_grid), length(station_order),
                  dimnames = list(NULL, station_order))
for (r in seq_len(nrow(row_grid))) {
  z <- d[k_c == row_grid$k_c[r] & c_C == row_grid$c_C[r]][match(station_order, station_id)]
  display[r, ] <- fifelse(!z$rejected, 0L,
                          fifelse(z$temperature_direction == "Above", 1L, -1L))
}

output_file <- file.path(results_dir, "tuning_sensitivity.png")
png(output_file, width = 3400, height = 2250, res = 300, bg = "white")
par(mar = c(7.5, 8.4, 5.2, 2.0), family = "sans", xaxs = "i", yaxs = "i")
nr <- nrow(display); nc <- ncol(display)
plot(NA, xlim = c(.5, nc + .5), ylim = c(nr + .5, .5), axes = FALSE, ann = FALSE)
palette <- c("#2E86DE", "#FFFFFF", "#E74C3C")
for (i in seq_len(nr)) for (j in seq_len(nc)) {
  rect(j - .5, i - .5, j + .5, i + .5,
       col = palette[display[i, j] + 2L], border = "#D5DADF", lwd = .7)
}
axis(1, at = seq_len(nc), labels = station_order, las = 2,
     tick = FALSE, line = -.3, cex.axis = .78)
row_labels <- parse(text = sprintf("k[c] == '%0.1f' ~~ ',' ~~ c[C] == '%0.1f'",
                                 row_grid$k_c, row_grid$c_C))
axis(2, at = seq_len(nr), labels = row_labels, las = 1,
     tick = FALSE, line = -.4, cex.axis = .76)
box(col = "#929AA1", lwd = .8)
mtext("Station ID", side = 1, line = 6.3, cex = 1.0, font = 2)
mtext("Parameter combination", side = 2, line = 6.8, cex = 1.0, font = 2)
legend("top", inset = c(0, -.145), xpd = NA, horiz = TRUE, bty = "n",
       legend = c("Above common temperature component",
                  "Below common temperature component", "Not detected"),
       pch = 22, pt.bg = c("#E74C3C", "#2E86DE", "#FFFFFF"),
       col = c("#9E2B20", "#145A91", "#929AA1"),
       pt.cex = 1.65, cex = .96, x.intersp = .8)
dev.off()

fwrite(cbind(row_grid, as.data.table(display)),
       file.path(results_dir, "tuning_detection_matrix.csv"))
message("Saved: ", output_file)
