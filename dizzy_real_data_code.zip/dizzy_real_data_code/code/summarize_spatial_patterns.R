options(stringsAsFactors = FALSE)
suppressPackageStartupMessages({
  library(data.table)
  library(sf)
})

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (!length(script_arg)) stop("Run this file with Rscript.")
this_file <- normalizePath(sub("^--file=", "", script_arg[1L]), winslash = "/", mustWork = TRUE)
bundle_dir <- normalizePath(file.path(dirname(this_file), ".."), winslash = "/")
results_name <- Sys.getenv("DIVVY_RESULTS_DIR", unset = "results")
results_dir <- file.path(bundle_dir, results_name)

station_file <- file.path(results_dir, "station_results.csv")
panel_file <- file.path(bundle_dir, "data", "divvy2019_q1_updated_model_data.csv")
water_file <- file.path(bundle_dir, "data", "tiger2019",
                        "tl_2019_17031_areawater", "tl_2019_17031_areawater.shp")
required <- c(station_file, panel_file, water_file)
if (any(!file.exists(required))) stop("Missing required input file(s).")

stations <- fread(station_file)
stations[, station_id := as.character(station_id)]
panel <- fread(panel_file)
panel[, `:=`(station_id = as.character(station_id), date = as.IDate(date))]
panel[, weekend := as.POSIXlt(as.Date(date))$wday %in% c(0L, 6L)]

station_points <- st_as_sf(stations, coords = c("station_lon", "station_lat"),
                           crs = 4326, remove = FALSE)
station_points_m <- st_transform(station_points, 26916)

water <- st_read(water_file, quiet = TRUE)
name_field <- intersect(c("FULLNAME", "BASENAME", "NAME"), names(water))[1L]
if (is.na(name_field)) stop("No water-body name field found.")
lake <- water[tolower(water[[name_field]]) %in% c("lk michigan", "lake michigan"), ]
if (!nrow(lake)) stop("Lake Michigan polygon not found in the TIGER/Line layer.")
lake_boundary_m <- st_boundary(st_transform(st_union(lake), 26916))

lake_ids <- stations[
  rejected_joint_test == TRUE & temperature_direction == "Above" &
    !station_id %in% c("597", "320"), station_id
]
lake_rows <- stations[match(lake_ids, station_id)]
lake_points <- station_points_m[match(lake_ids, station_points_m$station_id), ]
lake_rows[, lake_shore_distance_km :=
            as.numeric(st_distance(lake_points, lake_boundary_m)) / 1000]

cta <- data.table(
  station_id = c("597", "320"),
  nearest_cta_station = c("Main (Purple Line)", "Racine (Blue Line)"),
  cta_lon = c(-87.679538, -87.659458),
  cta_lat = c(42.033456, 41.875920)
)
cta_points <- st_transform(st_as_sf(cta, coords = c("cta_lon", "cta_lat"),
                                    crs = 4326, remove = FALSE), 26916)
cta_rows <- stations[match(cta$station_id, station_id)]
cta_station_points <- station_points_m[match(cta$station_id, station_points_m$station_id), ]
cta[, distance_to_cta_km := vapply(seq_len(.N), function(i)
  as.numeric(st_distance(cta_station_points[i, ], cta_points[i, ])) / 1000,
  numeric(1))]
cta_rows <- cbind(cta_rows, cta[, .(nearest_cta_station, cta_lat, cta_lon,
                                    distance_to_cta_km)])

university <- st_transform(st_sfc(st_point(c(-87.5997, 41.7897)), crs = 4326), 26916)
university_ids <- stations[
  rejected_joint_test == TRUE & temperature_direction == "Below" &
    !station_id %in% c("457", "252"), station_id
]
university_rows <- stations[match(university_ids, station_id)]
university_points <- station_points_m[match(university_ids, station_points_m$station_id), ]
university_rows[, distance_to_uchicago_km :=
                  as.numeric(st_distance(university_points, university)) / 1000]

demand_by_station <- panel[, .(
  mean_daily_departures = mean(departures),
  median_daily_departures = median(departures),
  total_departures = sum(departures),
  zero_departure_days = sum(departures == 0),
  weekday_mean = mean(departures[!weekend]),
  weekend_mean = mean(departures[weekend])
), by = .(station_id, station_name)]
demand_by_station <- merge(
  demand_by_station,
  stations[, .(station_id, rejected_joint_test, temperature_direction)],
  by = "station_id", all.x = TRUE
)

low_usage <- demand_by_station[station_id %in% c("252", "457")]
low_usage_comparison <- rbind(
  low_usage[, .(group = paste0("Station ", station_id), stations = 1L,
                mean_daily_departures, median_daily_departures,
                total_departures, zero_departure_days)],
  low_usage[, .(group = "Stations 252 and 457 combined", stations = .N,
                mean_daily_departures = mean(mean_daily_departures),
                median_daily_departures = mean(median_daily_departures),
                total_departures = sum(total_departures),
                zero_departure_days = mean(zero_departure_days))],
  demand_by_station[rejected_joint_test == FALSE,
    .(group = "Not-rejected stations", stations = .N,
      mean_daily_departures = mean(mean_daily_departures),
      median_daily_departures = median(mean_daily_departures),
      total_departures = sum(total_departures),
      zero_departure_days = mean(zero_departure_days))]
)

group_demand <- function(group_ids, label) {
  z <- panel[station_id %in% group_ids]
  data.table(
    group = label,
    stations = uniqueN(z$station_id),
    mean_daily_departures = mean(z$departures),
    weekday_mean = mean(z[weekend == FALSE, departures]),
    weekend_mean = mean(z[weekend == TRUE, departures]),
    weekend_to_weekday_ratio = mean(z[weekend == TRUE, departures]) /
      mean(z[weekend == FALSE, departures])
  )
}
spatial_group_summary <- rbind(
  data.table(
    group = "Lakefront Above stations excluding 597 and 320",
    stations = nrow(lake_rows),
    mean_distance_km = mean(lake_rows$lake_shore_distance_km),
    median_distance_km = median(lake_rows$lake_shore_distance_km),
    maximum_distance_km = max(lake_rows$lake_shore_distance_km)
  ),
  data.table(
    group = "UChicago-area Below stations excluding 457 and 252",
    stations = nrow(university_rows),
    mean_distance_km = mean(university_rows$distance_to_uchicago_km),
    median_distance_km = median(university_rows$distance_to_uchicago_km),
    maximum_distance_km = max(university_rows$distance_to_uchicago_km)
  )
)

fwrite(lake_rows[, .(station_id, station_name, lake_shore_distance_km,
                     p_value, p_bh)],
       file.path(results_dir, "above_lake_shore_distances.csv"))
fwrite(cta_rows[, .(station_id, station_name, nearest_cta_station,
                    distance_to_cta_km, p_value, p_bh)],
       file.path(results_dir, "above_cta_distances.csv"))
fwrite(university_rows[, .(station_id, station_name, distance_to_uchicago_km,
                           mean_daily_departures, p_value, p_bh)],
       file.path(results_dir, "below_uchicago_distances.csv"))
fwrite(low_usage_comparison, file.path(results_dir, "below_low_usage_comparison.csv"))
fwrite(spatial_group_summary, file.path(results_dir, "spatial_distance_summary.csv"))
fwrite(rbind(
  group_demand(lake_ids, "Lakefront Above stations excluding 597 and 320"),
  group_demand(university_ids, "UChicago-area Below stations excluding 457 and 252")
), file.path(results_dir, "spatial_group_demand_summary.csv"))

message("Spatial summaries saved to: ", results_dir)
