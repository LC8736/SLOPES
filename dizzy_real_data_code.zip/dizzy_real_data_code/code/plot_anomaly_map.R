options(stringsAsFactors = FALSE)
suppressPackageStartupMessages({
  library(data.table)
  library(sf)
  library(ggplot2)
  library(ggrepel)
  library(ragg)
  library(scales)
})

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (!length(script_arg)) stop("Run this file with Rscript.")
this_file <- normalizePath(sub("^--file=", "", script_arg[1L]), winslash = "/", mustWork = TRUE)
bundle_dir <- normalizePath(file.path(dirname(this_file), ".."), winslash = "/")
results_name <- Sys.getenv("DIVVY_RESULTS_DIR", unset = "results")
results_dir <- file.path(bundle_dir, results_name)

station_file <- file.path(results_dir, "station_results.csv")
tiger_dir <- file.path(bundle_dir, "data", "tiger2019")
roads_file <- file.path(tiger_dir, "tl_2019_17031_roads", "tl_2019_17031_roads.shp")
water_file <- file.path(tiger_dir, "tl_2019_17031_areawater", "tl_2019_17031_areawater.shp")
linear_water_file <- file.path(tiger_dir, "tl_2019_17031_linearwater", "tl_2019_17031_linearwater.shp")
required <- c(station_file, roads_file, water_file, linear_water_file)
if (any(!file.exists(required))) {
  stop("Missing input file(s):\n", paste(required[!file.exists(required)], collapse = "\n"))
}

west <- -87.720; east <- -87.545; south <- 41.760; north <- 42.065
crop_box <- st_bbox(c(xmin = west, ymin = south, xmax = east, ymax = north), crs = 4326)

roads <- st_read(roads_file, quiet = TRUE)
water <- st_read(water_file, quiet = TRUE)
linear_water <- st_read(linear_water_file, quiet = TRUE)
tiger_crop <- st_bbox(st_transform(st_as_sfc(crop_box), st_crs(roads)))
roads <- suppressWarnings(st_crop(roads, tiger_crop))
water <- suppressWarnings(st_crop(water, tiger_crop))
linear_water <- suppressWarnings(st_crop(linear_water, tiger_crop))
roads <- suppressWarnings(st_collection_extract(roads, "LINESTRING"))
water <- suppressWarnings(st_collection_extract(water, "POLYGON"))
linear_water <- suppressWarnings(st_collection_extract(linear_water, "LINESTRING"))
major_roads <- roads[roads$MTFCC %in% c("S1100", "S1200"), ]
local_roads <- roads[roads$MTFCC %in% c("S1400", "S1500", "S1630", "S1640"), ]

# Convert sf geometry to ordinary longitude-latitude paths.  The application
# figure intentionally uses a square display area, matching the original
# manuscript map, rather than preserving the geographic aspect ratio.  The
# coordinates themselves are unchanged; distances must not be measured from
# this display.
line_coordinates <- function(x) {
  xy <- as.data.frame(st_coordinates(x))
  level_columns <- grep("^L[0-9]+$", names(xy), value = TRUE)
  xy$group <- interaction(xy[, level_columns, drop = FALSE], drop = TRUE)
  xy
}
polygon_coordinates <- function(x) {
  xy <- as.data.frame(st_coordinates(x))
  level_columns <- grep("^L[0-9]+$", names(xy), value = TRUE)
  xy$group <- interaction(xy[, level_columns, drop = FALSE], drop = TRUE)
  xy
}
water_xy <- polygon_coordinates(water)
local_roads_xy <- line_coordinates(local_roads)
major_roads_xy <- line_coordinates(major_roads)
linear_water_xy <- line_coordinates(linear_water)

stations <- fread(station_file)
stopifnot(nrow(stations) == 344L, sum(stations$rejected_joint_test) == 22L)
stations[, map_group := fifelse(
  temperature_direction == "Above", "Above benchmark",
  fifelse(temperature_direction == "Below", "Below benchmark", "Not rejected")
)]
stations[, map_group := factor(map_group,
  levels = c("Above benchmark", "Below benchmark", "Not rejected"))]

# Draw ordinary stations first. Context symbols are added last so that the CTA
# symbol remains visible where it overlaps station 597.
stations[, draw_order := as.integer(map_group != "Not rejected")]
setorder(stations, draw_order)
detected <- stations[rejected_joint_test == TRUE]

landmarks <- data.table(
  label = c("University of Chicago", rep("CTA station", 6L), "Downtown (The Loop)"),
  type = c("University", rep("CTA", 6L), "Downtown"),
  lon = c(-87.5997, -87.6492, -87.6531, -87.6497,
          -87.659458, -87.6260, -87.679538, -87.6298),
  lat = c(41.7897, 41.9107, 41.9252, 41.8755,
          41.875920, 41.8674, 42.033456, 41.8819)
)

group_levels <- c("Above benchmark", "Below benchmark", "Not rejected",
                  "University of Chicago", "CTA station", "Downtown (The Loop)")
stations[, `:=`(
  lon = station_lon,
  lat = station_lat,
  group = as.character(map_group),
  point_size = fifelse(rejected_joint_test, 3.2, 1.4)
)]
landmarks[, group := fifelse(type == "University", "University of Chicago",
                     fifelse(type == "CTA", "CTA station", "Downtown (The Loop)"))]
landmarks[, point_size := fifelse(type == "CTA", 2.8, 4.6)]
point_data <- rbind(
  stations[, .(lon, lat, group, point_size)],
  landmarks[, .(lon, lat, group, point_size)]
)
point_data[, group := factor(group, levels = group_levels)]

fill_values <- c(
  "Above benchmark" = "#E74C3C",
  "Below benchmark" = "#2E86DE",
  "Not rejected" = "#777777",
  "University of Chicago" = "#7D3C98",
  "CTA station" = "#F39C12",
  "Downtown (The Loop)" = "#8E5B3A"
)
outline_values <- c(
  "Above benchmark" = "#9E2B20",
  "Below benchmark" = "#145A91",
  "Not rejected" = "white",
  "University of Chicago" = "white",
  "CTA station" = "white",
  "Downtown (The Loop)" = "white"
)
shape_values <- c(
  "Above benchmark" = 21,
  "Below benchmark" = 21,
  "Not rejected" = 21,
  "University of Chicago" = 24,
  "CTA station" = 23,
  "Downtown (The Loop)" = 25
)

p <- ggplot() +
  geom_polygon(data = water_xy, aes(X, Y, group = group),
               fill = "#DDEFF4", colour = "#B8D7E1", linewidth = .12) +
  geom_path(data = local_roads_xy, aes(X, Y, group = group),
            colour = "#E2E4E5", linewidth = .10) +
  geom_path(data = major_roads_xy, aes(X, Y, group = group),
            colour = "#BCC3C8", linewidth = .28) +
  geom_path(data = linear_water_xy, aes(X, Y, group = group),
            colour = "#AFD3DF", linewidth = .25) +
  geom_point(data = point_data,
             aes(lon, lat, fill = group, colour = group,
                 shape = group, size = point_size), stroke = .65) +
  scale_size_identity() +
  # IDs are placed immediately to the right without leader lines.
  geom_text_repel(data = detected,
                  aes(station_lon, station_lat, label = station_id),
                  direction = "y", hjust = 0, nudge_x = .0016,
                  min.segment.length = Inf, segment.color = NA,
                  box.padding = .08, point.padding = .03,
                  size = 2.7, fontface = "bold", colour = "#17212B",
                  max.overlaps = Inf) +
  annotate("text", x = -87.6045, y = 41.7842,
           label = "University of Chicago", hjust = 1, vjust = 1,
           size = 3.0, fontface = "bold", colour = "#4A1D59") +
  annotate("text", x = -87.6335, y = 41.8795,
           label = "Downtown (The Loop)", hjust = 1, vjust = 1,
           size = 3.0, fontface = "bold", colour = "#5D3A24") +
  annotate("text", x = -87.557, y = 41.940,
           label = "Lake Michigan", angle = 90,
           size = 3.4, fontface = "italic", colour = "#5E8795") +
  annotate("segment", x = -87.706, xend = -87.706,
           y = 42.022, yend = 42.047,
           linewidth = .55, colour = "#30343B",
           arrow = arrow(length = grid::unit(.10, "inches"), type = "closed")) +
  annotate("text", x = -87.706, y = 42.053, label = "N",
           size = 3.4, fontface = "bold", colour = "#30343B") +
  scale_fill_manual(values = fill_values, breaks = group_levels, drop = FALSE) +
  scale_colour_manual(values = outline_values, breaks = group_levels, drop = FALSE) +
  scale_shape_manual(values = shape_values, breaks = group_levels, drop = FALSE) +
  coord_cartesian(xlim = c(west, east), ylim = c(south, north), expand = FALSE) +
  theme_void(base_family = "sans") +
  theme(
    plot.background = element_rect(fill = "white", colour = NA),
    panel.background = element_rect(fill = "#FAFAF9", colour = NA),
    legend.position = c(.965, .975),
    legend.justification = c(1, 1),
    legend.background = element_rect(fill = alpha("white", .96),
                                     colour = "#AAB2B8", linewidth = .3),
    legend.text = element_text(size = 11),
    legend.margin = margin(8, 10, 8, 10)
  ) +
  guides(fill = guide_legend(
           title = NULL,
           override.aes = list(
             shape = unname(shape_values),
             size = c(4.2, 4.2, 3.2, 4.8, 3.8, 4.8),
             colour = unname(outline_values)
           )),
         colour = "none", shape = "none")

output_file <- file.path(results_dir, "updated_model_anomaly_map.png")
ggsave(output_file, p, width = 10.8, height = 10.8, dpi = 330,
       bg = "white", device = ragg::agg_png)
message("Saved: ", output_file)
