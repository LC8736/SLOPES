# Chicago Divvy updated real-data application

This directory is the self-contained real-data companion for the revised
Chicago Divvy application. It reproduces the updated multivariate
heterogeneous-slope model, the 22 station-level joint discoveries, the
cross-station residual-correlation diagnostics, the ACF and ARCH-LM
diagnostics, the tuning-parameter sensitivity analysis, and the application
map, test-statistic density plot, and spatial summaries.

## 1. Updated model

For station `i` and day `t`, the application uses

```text
Y_it = alpha_i
       + beta_i,Temp * Temp_it
       + beta_i,PRCP * PRCP_it
       + beta_i,SWE  * SWE_it
       + theta_1 * Weekend_t
       + theta_2 * Holiday_t
       + e_it.
```

The response is `log(1 + daily departures)`. The response and the three
continuous weather variables are standardized once over all `N*T = 30,960`
station-day observations and then demeaned within station. `Weekend` and
`Holiday` remain 0/1 variables and are demeaned within station together with
the other variables. The station intercepts are removed by this within
transformation.

The heterogeneous coefficient is the three-dimensional vector

```text
beta_i = (beta_i,Temp, beta_i,PRCP, beta_i,SWE)'.
```

Each station is tested against the screened common vector with a three-degree-
of-freedom joint statistic. A red or blue map symbol describes only whether
the station's temperature component is above or below the common temperature
component; the rejection itself concerns all three weather slopes jointly.

The default tuning parameters are

```text
C0 = c_C * T^(-1/3),  c_C = 1.0,  k_c = 0.6,
nominal FDR level = 0.05.
```

The preliminary reference set contains `floor(0.6 * 344) = 206` stations.

## 2. Data and sample

- Period: 1 January through 31 March 2019.
- Stations: 344.
- Calendar days: 90.
- Balanced-panel observations: 30,960.
- Outcome: number of trips starting at a station on a day.
- Temperature: daily mean temperature in degrees C, calculated from Daymet
  daily maximum and minimum temperature.
- PRCP: Daymet daily total water-equivalent precipitation in millimetres.
- SWE: Daymet snow water equivalent in `kg/m^2`, numerically equivalent to
  millimetres of liquid water depth.
- Weekend: one on Saturday and Sunday, zero otherwise.
- Holiday: one on 1 January, 21 January, and 18 February 2019, zero otherwise.

The 344 stations occupy 103 nearest Daymet 1 km grid cells. Stations sharing a
grid cell have identical weather inputs on a given date.

The model-ready file `data/divvy2019_q1_updated_model_data.csv` contains:

| Column | Meaning |
|---|---|
| `station_id` | Divvy station identifier |
| `date` | Calendar date |
| `station_name` | Station name |
| `departures` | Trips starting at the station that day |
| `temp_it_c` | Daymet mean temperature, degrees C |
| `prcp_it_mm` | Daymet total precipitation, mm |
| `swe_kg_m2` | Daymet snow water equivalent, kg/m2 |

Station coordinates and nearest-grid identifiers are stored in
`data/divvy2019_station_temperature_grid_mapping.csv`.

Trip data originate from Divvy's public historical system data:
<https://divvybikes.com/system-data>. Weather data originate from Daymet
Version 4: <https://daymet.ornl.gov/>. Geographic context is drawn locally
from the U.S. Census Bureau's 2019 TIGER/Line Shapefiles for Cook County:
<https://www.census.gov/geographies/mapping-files/time-series/geo/tiger-line-file.2019.html>.

## 3. Verified main results

| Quantity | Result |
|---|---:|
| Stations | 344 |
| Days | 90 |
| Preliminary reference stations | 206 |
| Common standardized temperature slope | 0.406508 |
| Common standardized PRCP slope | -0.111894 |
| Common standardized SWE slope | -0.085916 |
| Temperature slope in log units per 1 C | 0.058884 |
| PRCP slope in log units per 1 mm | -0.028432 |
| SWE slope in log units per 1 kg/m2 | -0.008063 |
| Temperature multiplicative association | 6.065% per 1 C |
| PRCP multiplicative association | -2.803% per 1 mm |
| SWE multiplicative association | -0.803% per 1 kg/m2 |
| Weekend coefficient on standardized response scale | -0.593427 |
| Holiday coefficient on standardized response scale | -0.693163 |
| BH rejection threshold on the raw-p-value scale | 0.003198 |
| Joint discoveries | 22 |
| Temperature component above common value | 14 |
| Temperature component below common value | 8 |

The raw-scale weather slopes are obtained from

```text
beta_raw,j = beta_std,j * sd(log(1 + departures)) / sd(X_j).
```

The reported one-unit multiplicative association is

```text
100 * {exp(beta_raw,j) - 1}%.
```

It applies to the conditional geometric scale of `1 + departures`, rather
than being an exact percentage change in the arithmetic conditional mean.
These are within-station conditional associations and are not causal effects.

The figure `results/test_statistic_density.png` shows the kernel density of the
three-degree-of-freedom joint test statistic across all 344 stations. The
vertical dashed line is the BH rejection threshold expressed on the test-
statistic scale: the raw-p-value cutoff of 0.003198 corresponds to a chi-square
cutoff of 13.80. Long red tick marks identify the 14 detected stations whose
temperature component is above the common temperature slope; short blue tick
marks identify the 8 detected stations whose temperature component is below
it. The Above/Below labels refer only to the temperature component, whereas
rejection is based jointly on the Temperature, PRCP, and SWE slopes.

## 4. Residual diagnostics

The cross-station diagnostic uses unrestricted residuals that allow each
station to have its own temperature, PRCP, and SWE slopes. Across all 58,996
station pairs, the signed mean correlation is 0.265, the mean absolute
correlation is 0.297, and the median absolute correlation is 0.288. The 75th,
90th, and 95th percentiles of absolute correlation are 0.411, 0.520, and
0.596. A total of 52.6% of pairs have absolute correlation below 0.3 and 0.8%
exceed 0.8.

For temporal diagnostics, the median residual ACF is 0.125 at lag 1 and 0.131
at lag 7. The seven-lag ARCH-LM test rejects, after BH adjustment across
stations, for 11 of 344 stations (3.2%) and 8 of the 206 preliminary reference
stations (3.9%). These results indicate modest serial dependence for a typical
station and limited evidence of conditional heteroskedasticity across the
panel, although they do not establish that the temporal error assumptions hold
for every station.

## 5. Tuning sensitivity

The supplied sensitivity analysis uses

```text
c_C in {1.0, 1.1, 1.2, 1.3}
k_c in {0.5, 0.6, 0.7, 0.8}.
```

Across the 16 combinations, the number of discoveries ranges from 21 to 23.
Twenty-one stations are detected under every combination. At fixed
`k_c = 0.6`, changing `c_C` from 1.0 to 1.3 leaves the default 22-station set
unchanged. The remaining differences concern only boundary stations 90 and
331.

## 6. Directory structure

```text
dizzy_real_data_code/
|-- README.md
|-- code/
|   |-- run_all.R
|   |-- run_divvy2019_q1_updated_model.R
|   |-- plot_anomaly_map.R
|   |-- plot_test_statistic_density.R
|   |-- plot_tuning_sensitivity.R
|   `-- summarize_spatial_patterns.R
|-- data/
|   |-- divvy2019_q1_updated_model_data.csv
|   |-- divvy2019_station_temperature_grid_mapping.csv
|   `-- tiger2019/
|       |-- tl_2019_17031_roads/
|       |-- tl_2019_17031_areawater/
|       `-- tl_2019_17031_linearwater/
`-- results/
    |-- model_summary.csv
    |-- standardization_parameters.csv
    |-- station_results.csv
    |-- detected_anomalies.csv
    |-- residual_correlation_summary.csv
    |-- station_acf.csv
    |-- acf_summary.csv
    |-- station_arch_lm.csv
    |-- arch_lm_summary.csv
    |-- tuning_sensitivity_summary.csv
    |-- tuning_station_results.csv
    |-- tuning_detection_matrix.csv
    |-- tuning_sensitivity.png
    |-- updated_model_anomaly_map.png
    |-- test_statistic_density.png
    |-- above_lake_shore_distances.csv
    |-- above_cta_distances.csv
    |-- below_uchicago_distances.csv
    |-- below_low_usage_comparison.csv
    |-- spatial_distance_summary.csv
    |-- spatial_group_demand_summary.csv
    `-- sessionInfo.txt
```

## 7. Reproduction instructions

Required R packages:

```r
data.table
sf
ggplot2
ggrepel
ragg
scales
```

From the directory containing this README, run all analyses with:

```bash
Rscript code/run_all.R
```

Newly reproduced outputs are written to `reproduced_results/`, preserving the
verified files in `results/`. To rebuild the verified results deliberately,
run:

```bash
DIVVY_RESULTS_DIR=results Rscript code/run_all.R
```

The scripts may also be run separately in this order:

```bash
Rscript code/run_divvy2019_q1_updated_model.R
DIVVY_RESULTS_DIR=reproduced_results Rscript code/plot_tuning_sensitivity.R
DIVVY_RESULTS_DIR=reproduced_results Rscript code/plot_anomaly_map.R
DIVVY_RESULTS_DIR=reproduced_results Rscript code/summarize_spatial_patterns.R
```

## 8. Interpretation boundary

The 22 discoveries are stations detected using a nominal FDR target of 5%
under the proposed procedure and working model. Because the residuals exhibit
cross-station dependence, the formal FDR guarantee derived under
cross-sectional independence does not directly apply to this application; the
results should therefore be interpreted together with the reported
residual-dependence and tuning-sensitivity diagnostics.

The lakefront, transit-proximity, university-area, low-usage, and
weekday–weekend interpretations are post-selection descriptive analyses. They
should be treated as plausible contextual explanations and hypotheses for
future investigation, rather than as causal or selection-adjusted conclusions.
